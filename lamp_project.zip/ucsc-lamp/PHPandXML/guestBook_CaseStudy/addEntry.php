<?php

echo "Name: " . htmlspecialchars($_POST['Name']) . "<br>";
echo "Email: " . htmlspecialchars($_POST['Email']) . "<br>";
echo "Comments: " . htmlspecialchars($_POST['Comments']) . "<br>";

?>
