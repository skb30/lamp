<html>
<head><title></title></head>
<body>

<h2> Please submit your comments here </h2>
<br>
<form method="POST" action="addEntry.php">
Name
<input name="Name" type="text">
<br>
Email
<input name="Email" type="text">
<br>
Comments
<textarea name="Comments" cols="50" rows="5"></textarea>
<br>
<input type="Submit" value="submit">
</form>
</body>
</html>