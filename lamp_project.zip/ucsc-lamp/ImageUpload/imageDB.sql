CREATE DATABASE images;
USE images;

CREATE TABLE images (
	ID mediumint(9) AUTO_INCREMENT PRIMARY KEY,
	image blob
);
