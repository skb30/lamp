<?php

interface iCalculateArea
{
    public function calculateArea();
}

?>
