<html>
<head><title></title></head>
<body>
<?php
echo "$_POST[Choice1]<br>";
echo "$_POST[Choice2]<br>";
echo "$_POST[Choice3]<br>";
?>
</body>
</html>
