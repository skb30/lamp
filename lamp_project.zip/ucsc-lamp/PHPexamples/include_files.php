<html>
<head><title></title></head>
<body>
<?php
if (isset($_POST['posted'])) {
   $choice = $_POST['choice'];
   if ($choice <> "") {
      include("file" . $choice . ".txt");
      echo "<hr>";
   }
}
?>
<form method="POST" action="include_files.php">
<input type="hidden" name="posted" value="true">
What file do you wish to include?
<select name="choice">
<option value="1">file one</option>
<option value="2">file two</option>
</select>
<br>
<br>
<input type="submit" value="Get Text">
</form> 
</body>
</html>
