<?php
include 'includes/functions.php';
postIt();

header('Location: index.html');
?>

